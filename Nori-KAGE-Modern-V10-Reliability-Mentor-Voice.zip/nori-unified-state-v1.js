/* NORI UNIFIED STATE V1
 * One local state contract for the Modern UI + Nori V3 systems.
 * The model may propose; state is written by deterministic application code.
 * Network/cloud state is a synchronized mirror, never a reason to block core UI.
 */
(function(g){'use strict';
  const KEY='nori_unified_state_v1';
  let rebuilding=false, queued=false;
  const read=(k,fb)=>{try{const v=JSON.parse(localStorage.getItem(k)||'null');return v==null?fb:v}catch(_){return fb}};
  const arr=(k)=>{const v=read(k,[]);return Array.isArray(v)?v:[]};
  const obj=(k)=>{const v=read(k,{});return v&&typeof v==='object'&&!Array.isArray(v)?v:{} };
  const clone=v=>{try{return structuredClone(v)}catch(_){return JSON.parse(JSON.stringify(v))}};
  function modern(){return read('kage_state_v3',null)};
  function build(){
    const m=modern()||{};
    const history=read('nori_eval_history_all_subjects',{});
    const unified={
      schema:1,updatedAt:new Date().toISOString(),
      identity:clone(m.profile||{}),
      academic:{subjects:clone(m.subjects||{}),semester:m.semester||'SEM1',assessments:clone(history),assignments:arr('nori_command_assignments').length?arr('nori_command_assignments'):clone(m.assignments||[]),studyBlocks:clone(m.studyBlocks||[]),mistakes:arr('nori_academic_mistakes_v14')},
      kage:{merit:Number(m.merit)||0,focusMinutes:Number(m.focusMinutes)||0,blockedApps:clone(m.blockedApps||[]),recovery:arr('nori_recovery_records'),overrides:arr('nori_override_history_all_subjects'),breaches:obj('nori_breach_history_by_category')},
      planning:{goals:clone((obj('nori_assistance_profile_v36')||{}).goals||[]),calendar:arr('nori_calendar_events_v1'),alarms:arr('nori_voice_alarms').length?arr('nori_voice_alarms'):arr('nori_voice_alarms_v1')},
      cognition:{memory:obj('nori_v26_memory'),conversations:clone(m.noriHistory||[]),chatHistory:clone(m.chatHistory||[]),notes:clone(m.notes||[]),library:clone(m.library||[])},
      system:{theme:m.theme||'kage-modern',noriInterface:m.noriInterface||'CLASSIC',jarvisState:m.jarvisState||'IDLE',online:navigator.onLine!==false}
    };
    return unified;
  }
  function persist(u){
    try{localStorage.setItem(KEY,JSON.stringify(u));return true}catch(e){console.warn('Nori unified state write failed',e.message);return false}
  }
  function rebuild(){if(rebuilding){queued=true;return}rebuilding=true;try{persist(build())}finally{rebuilding=false;if(queued){queued=false;setTimeout(rebuild,0)}}}
  function snapshot(){const u=read(KEY,null);return u||build()}
  function status(){const u=snapshot();return {schema:u.schema,updatedAt:u.updatedAt,online:navigator.onLine!==false,hasModern:!!modern(),counts:{assignments:(u.academic.assignments||[]).length,subjects:Object.keys(u.academic.subjects||{}).length,studyBlocks:(u.academic.studyBlocks||[]).length,assessments:Object.values(u.academic.assessments||{}).reduce((n,a)=>n+(Array.isArray(a)?a.length:0),0),notes:(u.cognition.notes||[]).length,calendar:(u.planning.calendar||[]).length,alarms:(u.planning.alarms||[]).length}}}
  function onModernSave(key,value){if(key===KEY)return;setTimeout(rebuild,0)}
  function init(){
    if(typeof g.noriStorageOnWrite==='function')g.noriStorageOnWrite(onModernSave);
    rebuild();
    window.addEventListener('online',()=>{rebuild();document.dispatchEvent(new CustomEvent('nori:state-changed',{detail:{reason:'online'}}))});
    window.addEventListener('offline',()=>{rebuild();document.dispatchEvent(new CustomEvent('nori:state-changed',{detail:{reason:'offline'}}))});
    document.addEventListener('nori:auth-ready',()=>{rebuild();g.NoriCanonicalSync?.syncAll?.().catch?.(()=>{});});
  }
  g.NoriUnifiedState={version:'1.0',key:KEY,build,snapshot,rebuild,status,persist};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})(window);
