/* NORI VISUAL V27 — stable image API + precise prompt handling. */
(function(g){'use strict';
  function normalize(prompt){return String(prompt||'').trim().replace(/\s+/g,' ')}
  async function generate(prompt,opts){
    prompt=normalize(prompt);if(!prompt)throw new Error('Describe the visual first.');opts=opts||{};
    const body={prompt:prompt,aspect_ratio:opts.aspect_ratio||'1:1',image_size:opts.image_size||'2K'};
    const base=String(g.NORI_API_BASE_URL||'').replace(/\/$/,'');
    const urls=[(base||'')+'/api/image',(base||'')+'/api/nori-image'];
    let last=null;
    for(const url of urls){try{
      const h={'Content-Type':'application/json'};try{if(g.noriSyncGetAccessToken){const t=g.noriSyncGetAccessToken();if(t)h.Authorization='Bearer '+t}}catch(_){ }
      const r=await fetch(url,{method:'POST',headers:h,body:JSON.stringify(body)});const d=await r.json().catch(()=>({}));
      if(r.status===404){last=new Error('Image API endpoint unavailable');continue;} if(!r.ok)throw new Error(d.error||'Image generation unavailable');
      if(d.b64_json){const img=document.createElement('img');img.src='data:'+(d.mime_type||'image/png')+';base64,'+d.b64_json;img.alt=prompt;img.className='nori-v26-generated-image';const o=document.createElement('div');o.className='nori-v26-image-modal';o.innerHTML='<div class="nori-v26-image-card"><button>×</button><div class="eyebrow">GENERATED VISUAL · '+(d.model||'NORI')+'</div></div>';o.querySelector('button').onclick=()=>o.remove();o.querySelector('.nori-v26-image-card').appendChild(img);document.body.appendChild(o);return d;}
      throw new Error('Image provider returned no image');
    }catch(e){last=e}}
    throw last||new Error('Image generation unavailable');
  }
  g.NoriVisualV27={generate:generate,version:27};
  g.NoriVisualV26=g.NoriVisualV27;
})(window);
