/* Public integration configuration only. No AI provider secrets belong here. */
window.NORI_MODERN_CONFIG=Object.freeze({
  brainEndpoint:'https://qrlvkxewyoceykaquapv.supabase.co/functions/v1/nori-brain',
  appVersion:'NORI-KAGE-MODERN-V2',
  avatarMode:'STATIC',
  targetAndroidApi:33
});
