/* NORI STRICT RUNTIME V1 — deterministic client-side policy gate. */
(function(g){'use strict';
 const RULES={version:'strict-runtime-v1',precedence:['human_override','safety','integrity','canonical_state','confirmed_profile','mentor_context','model_inference'],hard:['never fabricate state','never silently perform consequential side effects','never sacrifice established sleep requirements for optimization','never convert an uncertain inference into a user fact'],soft:['explain interventions','prefer one useful next action','preserve user autonomy','treat humor as context, not evidence against danger']};
 function evaluate(action,ctx){ctx=ctx||{}; const a=String(action||'').toLowerCase(); const blocks=[];
  if(/delete|erase|reset|send|submit|publish|purchase|change grade|change result/.test(a)&&!ctx.confirmed)blocks.push('confirmation_required');
  if(/stay up|skip sleep|sleep less|all nighter/.test(a)&&ctx.sleepProtected)blocks.push('sleep_protection');
  return {allowed:blocks.length===0,blocks,rules:RULES}; }
 function explain(code){return ({confirmation_required:'This changes something consequential, so Nori needs explicit confirmation.',sleep_protection:'Nori is protecting an established sleep requirement instead of optimizing through sleep loss.'})[code]||'A strict rule is active.'}
 g.NoriStrictRuntimeV1={rules:RULES,evaluate,explain,version:1};
})(window);
