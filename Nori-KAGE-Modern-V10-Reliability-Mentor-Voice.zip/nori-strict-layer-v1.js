/* NORI STRICT LAYER V1
 * Deterministic enforcement layer. It is deliberately separate from mentoring,
 * humor, and model inference. It can tighten behavior but cannot silently invent
 * facts or override Human Override / safety / server-authoritative rules.
 */
(function(g){'use strict';
  const VERSION='strict-v1';
  const KEY='nori_strict_layer_v1';
  function load(){try{return JSON.parse(localStorage.getItem(KEY)||'{}')}catch(_){return{}}}
  function save(x){try{localStorage.setItem(KEY,JSON.stringify(x))}catch(_){}
  }
  function settings(){const x=load();return Object.assign({enabled:true,academicFloor:80,requireConfirmation:true,noSilentStateChanges:true,protectSleep:true},x)}
  function set(patch){const x=Object.assign(settings(),patch||{}, {updatedAt:new Date().toISOString()});save(x);return x}
  function evaluate(input){
    const x=input||{}, s=settings(), state=x.state||{};
    const recovery=Array.isArray(state.recovery)?state.recovery:[];
    const activeRecovery=recovery.filter(r=>r && (r.active===true||r.status==='active'||r.state==='active')).length;
    const strict=[];
    if(!s.enabled)return {version:VERSION,enabled:false,directives:[],mode:'normal'};
    if(s.noSilentStateChanges)strict.push('Never silently change academic records, merit, recovery status, alarms, or profile data. Explain and request confirmation for consequential mutations.');
    if(s.protectSleep)strict.push('Protect established sleep requirements; do not recommend sacrificing sleep merely to optimize productivity.');
    if(activeRecovery)strict.push('An active recovery path is binding context; do not stack unrelated penalties or create harsher consequences without evidence and explicit authorization.');
    if(x.task==='academic')strict.push('Use recorded academic evidence before assumptions. If evidence is missing, say so instead of fabricating a score, assignment, or deadline.');
    if(x.action)strict.push('Actions affecting another app, device setting, restriction, alarm, or stored record require an explicit user-confirmation path unless the user has already enabled that exact automation.');
    return {version:VERSION,enabled:true,mode:strict.length?'strict':'normal',directives:strict,academicFloor:Number(s.academicFloor)||80,activeRecovery,confirmationRequired:!!s.requireConfirmation};
  }
  g.NoriStrictLayerV1={version:VERSION,settings:settings,set:set,evaluate:evaluate,systemPrompt:function(x){return evaluate(x).directives.join('\n')||'Operate normally while preserving truthfulness and user control.'}};
})(window);
