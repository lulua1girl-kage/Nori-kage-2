/* NORI SMART ALARM V2 — organized alarm planning layer over the existing alarm engine. */
(function(g){'use strict';
  const KEY='nori_smart_alarm_v2';
  const CATS=['wake','study','exam','routine','reminder','recovery','custom'];
  const PRI=['critical','high','normal','low'];
  function load(){try{return JSON.parse(localStorage.getItem(KEY)||'{}')||{}}catch(e){return {}}}
  function save(x){try{localStorage.setItem(KEY,JSON.stringify(x));return true}catch(e){return false}}
  function uid(){return 'sa_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7)}
  function all(){return g.noriVoiceAlarms&&g.noriVoiceAlarms.allAlarms?g.noriVoiceAlarms.allAlarms():[]}
  function dayKey(d){const x=new Date(d);return x.getFullYear()+'-'+String(x.getMonth()+1).padStart(2,'0')+'-'+String(x.getDate()).padStart(2,'0')}
  function minuteOf(a){return String(a.time||'').slice(0,5)}
  function score(a){return PRI.indexOf(a.priority||'normal')+1}
  function conflicts(a){return all().filter(x=>x.id!==a.id&&x.enabled!==false&&dayKey(x.date||Date.now())===dayKey(a.date||Date.now())&&Math.abs((minuteOf(x)||'00:00').replace(':','')-(minuteOf(a)||'00:00').replace(':',''))<15)}
  function plan(a){
    const p=Object.assign({category:'custom',priority:'normal',preAlertMinutes:0,snoozeMinutes:5,maxSnoozes:2,smartBrief:true,enabled:true},a||{});
    if(p.category==='wake'){p.priority=p.priority==='normal'?'high':p.priority;p.maxSnoozes=Math.min(p.maxSnoozes,2);}
    if(p.category==='exam'){p.priority='critical';p.preAlertMinutes=Math.max(10,p.preAlertMinutes||15);p.maxSnoozes=0;}
    if(p.category==='study'){p.preAlertMinutes=Math.max(0,p.preAlertMinutes||5);}
    if(p.category==='recovery'){p.preAlertMinutes=Math.max(0,p.preAlertMinutes||10);}
    return p;
  }
  function context(date){
    const d=dayKey(date),events=[];
    try{if(g.noriVoiceAlarms&&g.noriVoiceAlarms.relatedEvents)events.push(...g.noriVoiceAlarms.relatedEvents(d))}catch(e){}
    const seen={};return events.filter(e=>{const k=(e.kind||'')+'|'+(e.title||'')+'|'+(e.time||'');if(seen[k])return false;seen[k]=1;return true}).sort((a,b)=>String(a.time||'99:99').localeCompare(String(b.time||'99:99')));
  }
  function brief(a,when){
    const p=plan(a), ev=context(when), pieces=[];
    pieces.push(p.category==='wake'?'Wake-up alarm.':p.category==='exam'?'Exam alert.':p.category==='study'?'Study block.':p.category==='recovery'?'Recovery check.':(p.label||'Reminder')+'.');
    if(ev.length)pieces.push(ev.slice(0,4).map(e=>e.title+(e.time?' at '+e.time:'')).join('; ')+'.');
    if(p.priority==='critical')pieces.push('This is marked time-critical.');
    return pieces.join(' ');
  }
  function state(){return load()}
  function organize(){
    const a=all().map(plan).sort((x,y)=>score(y)-score(x)||String(x.time).localeCompare(String(y.time)));
    const s=load();s.lastPlanAt=new Date().toISOString();s.count=a.length;s.conflicts=a.flatMap(x=>conflicts(x).map(y=>[x.id,y.id].sort().join('|'))).filter((x,i,z)=>z.indexOf(x)===i);save(s);return {alarms:a,conflicts:s.conflicts};
  }
  async function create(data){
    if(!g.noriVoiceAlarms||!g.noriVoiceAlarms.add)throw new Error('alarm_engine_unavailable');
    const p=plan(data), c=conflicts(p);
    p.id=uid();p.smartId=p.id;p.createdAt=new Date().toISOString();
    if(c.length&&p.priority==='critical')p.conflictWarning='critical_alarm_overlap';
    const result=await g.noriVoiceAlarms.add(p);organize();return result;
  }
  function render(){
    if(!g.noriEl||!g.noriBottomNav)return g.noriRenderAlarms&&g.noriRenderAlarms();
    const wrap=noriEl('div',{class:'nori-command-wrap nori-suite-screen'});
    wrap.appendChild(noriRenderCommandHeader(false));wrap.appendChild(noriRenderBreadcrumb([{label:'NORI',hash:'#/'},{label:'Smart Alarms'}]));
    const planNow=organize();
    const card=noriEl('section',{class:'nori-section-card'});
    card.appendChild(noriEl('div',{class:'nori-section-head'},[noriEl('h2',{text:'Smart Alarm Center'}),noriEl('span',{class:'nori-state-chip planned',text:'ORGANIZED'} )]));
    card.appendChild(noriEl('p',{class:'nori-brief-main',text:'Nori organizes alarms by purpose and priority, checks nearby conflicts, builds contextual briefings, and preserves explicit user control over snooze and rescheduling.'}));
    const form=noriEl('div',{class:'nori-alarm-form'});
    const label=noriEl('input',{type:'text',placeholder:'What is this alarm for?'}),date=noriEl('input',{type:'date'}),time=noriEl('input',{type:'time'}),cat=noriEl('select',{}),pri=noriEl('select',{}),pre=noriEl('select',{});
    date.value=dayKey(Date.now());time.value='20:00';
    [['wake','Wake up'],['study','Study'],['exam','Exam'],['routine','Routine'],['reminder','Reminder'],['recovery','Recovery'],['custom','Custom']].forEach(x=>cat.appendChild(noriEl('option',{value:x[0],text:x[1]})));
    PRI.forEach(x=>pri.appendChild(noriEl('option',{value:x,text:x.toUpperCase()})));['0','5','10','15','30'].forEach(x=>pre.appendChild(noriEl('option',{value:x,text:x==='0'?'No pre-alert':x+' min early'})));
    [['Purpose',label],['Date',date],['Time',time],['Type',cat],['Priority',pri],['Pre-alert',pre]].forEach(x=>{const f=noriEl('div',{class:'nori-field'});f.appendChild(noriEl('label',{text:x[0]}));f.appendChild(x[1]);form.appendChild(f)});
    const add=noriEl('button',{class:'nori-btn nori-btn-primary',text:'CREATE SMART ALARM'});add.onclick=async()=>{try{await create({label:label.value.trim()||'Nori alarm',date:date.value,time:time.value,category:cat.value,priority:pri.value,preAlertMinutes:Number(pre.value)});noriRoute()}catch(e){alert(e.message||'Could not create alarm.')}};form.appendChild(add);card.appendChild(form);wrap.appendChild(card);
    const list=noriEl('section',{class:'nori-section-card'});list.appendChild(noriEl('div',{class:'nori-section-head'},[noriEl('h2',{text:'Alarm Plan'}),noriEl('span',{text:planNow.alarms.length+' scheduled'})]));
    const rows=noriEl('div',{class:'nori-verification-list'});if(!planNow.alarms.length)rows.appendChild(noriEl('div',{class:'nori-command-empty',text:'No alarms set.'}));
    planNow.alarms.forEach(a=>{const r=noriEl('div',{class:'nori-verification-row'});const l=noriEl('div',{});l.appendChild(noriEl('strong',{text:(a.label||'Nori alarm')+' · '+(a.category||'custom').toUpperCase()}));l.appendChild(noriEl('small',{text:(a.date||'')+' · '+(a.time||'')+' · '+(a.priority||'normal').toUpperCase()+(a.preAlertMinutes?' · '+a.preAlertMinutes+'m pre-alert':'')}));r.appendChild(l);const b=noriEl('button',{class:'nori-btn nori-btn-ghost',text:'TEST'});b.onclick=()=>g.noriVoiceAlarms.startAlarmSession(a,new Date());r.appendChild(b);rows.appendChild(r)});list.appendChild(rows);wrap.appendChild(list);wrap.appendChild(noriBottomNav('profile'));return wrap;
  }
  g.NoriSmartAlarmV2={categories:CATS,priorities:PRI,plan,conflicts,context,brief,organize,create,state,render};
  g.noriRenderAlarms=render;
})(window);
