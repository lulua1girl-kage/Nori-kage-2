/* Model-freshness check.
   Not the request-time circuit breaker in brain.js (that's per-instance,
   in-memory, and doesn't need an endpoint of its own). This is a slower,
   on-demand check: it actually asks each provider "is the model ID I have
   configured still one you support?" — the exact question that would have
   caught the gpt-5.6-luna/gpt-5.6-terra bug before it shipped, instead of
   after.
   GET only. Requires an authenticated (parent/admin) user, same as the
   other diagnostic-style endpoints in this API. */
const { cors, requireUser, rateLimit } = require("./_security");

const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-3.8-flash";
const OPENAI_MODEL = process.env.OPENAI_MODEL || "gpt-6-luna";
const OPENAI_REASONING_MODEL = process.env.OPENAI_REASONING_MODEL || "gpt-6-sol";
const OPENAI_BACKUP_MODEL = process.env.OPENAI_BACKUP_MODEL || OPENAI_MODEL;
const OPENAI_BACKUP_BASE_URL = process.env.OPENAI_BACKUP_BASE_URL || "https://api.openai.com/v1";
const ANTHROPIC_FAST_MODEL = process.env.ANTHROPIC_FAST_MODEL || "claude-haiku-4-5-20251001";
const ANTHROPIC_REASONING_MODEL = process.env.ANTHROPIC_REASONING_MODEL || "claude-sonnet-5";
const ANTHROPIC_BASE_URL = process.env.ANTHROPIC_BASE_URL || "https://api.anthropic.com/v1";
const GROQ_MODEL = process.env.GROQ_MODEL || "llama-3.3-70b-versatile";
const GROQ_BASE_URL = process.env.GROQ_BASE_URL || "https://api.groq.com/openai/v1";

async function withTimeout(promise, ms) {
  let timer;
  const timeout = new Promise(function (_, reject) { timer = setTimeout(function () { reject(new Error("timed out")); }, ms); });
  try { return await Promise.race([promise, timeout]); } finally { clearTimeout(timer); }
}

async function checkOpenAICompatible(label, baseUrl, apiKey, models) {
  if (!apiKey) return models.map(function (m) { return { provider: label, model: m, configured: false, stillListed: null, note: "no API key set" }; }); 
  try {
    const resp = await withTimeout(fetch(baseUrl.replace(/\/$/, "") + "/models", { headers: { Authorization: "Bearer " + apiKey } }), 6000);
    if (!resp.ok) throw new Error("HTTP " + resp.status);
    const data = await resp.json();
    const ids = new Set((data.data || []).map(function (m) { return m.id; }));
    return models.map(function (m) { return { provider: label, model: m, configured: true, stillListed: ids.has(m), checkedOk: true }; });
  } catch (e) {
    return models.map(function (m) { return { provider: label, model: m, configured: true, stillListed: null, checkedOk: false, error: e.message }; });
  }
}

async function checkGemini(models) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) return models.map(function (m) { return { provider: "gemini", model: m, configured: false, stillListed: null, note: "no API key set" }; });
  try {
    const resp = await withTimeout(fetch("https://generativelanguage.googleapis.com/v1beta/models?key=" + key), 6000);
    if (!resp.ok) throw new Error("HTTP " + resp.status);
    const data = await resp.json();
    const ids = new Set((data.models || []).map(function (m) { return String(m.name || "").replace(/^models\//, ""); }));
    return models.map(function (m) { return { provider: "gemini", model: m, configured: true, stillListed: ids.has(m), checkedOk: true }; });
  } catch (e) {
    return models.map(function (m) { return { provider: "gemini", model: m, configured: true, stillListed: null, checkedOk: false, error: e.message }; });
  }
}

async function checkAnthropic(models) {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return models.map(function (m) { return { provider: "anthropic", model: m, configured: false, stillListed: null, note: "no API key set" }; });
  try {
    const resp = await withTimeout(fetch(ANTHROPIC_BASE_URL.replace(/\/$/, "") + "/models", { headers: { "x-api-key": key, "anthropic-version": "2023-06-01" } }), 6000);
    if (!resp.ok) throw new Error("HTTP " + resp.status);
    const data = await resp.json();
    const ids = new Set((data.data || []).map(function (m) { return m.id; }));
    return models.map(function (m) { return { provider: "anthropic", model: m, configured: true, stillListed: ids.has(m), checkedOk: true }; });
  } catch (e) {
    return models.map(function (m) { return { provider: "anthropic", model: m, configured: true, stillListed: null, checkedOk: false, error: e.message }; });
  }
}

module.exports = async function handler(req, res) {
  cors(req, res);
  if (req.method === "OPTIONS") { res.status(204).end(); return; }
  if (req.method !== "GET") { res.status(405).json({ error: "GET only" }); return; }
  if (!(await rateLimit(req, "provider-model-check", 10, 60000))) { res.status(429).json({ error: "Too many requests" }); return; }
  const u = await requireUser(req, res);
  if (!u) return;

  try {
    const results = (await Promise.all([
      checkGemini([GEMINI_MODEL]),
      checkOpenAICompatible("openai", "https://api.openai.com/v1", process.env.OPENAI_API_KEY, [OPENAI_MODEL, OPENAI_REASONING_MODEL]),
      checkOpenAICompatible("openai-backup", OPENAI_BACKUP_BASE_URL, process.env.OPENAI_BACKUP_API_KEY, [OPENAI_BACKUP_MODEL]),
      checkAnthropic([ANTHROPIC_FAST_MODEL, ANTHROPIC_REASONING_MODEL]),
      checkOpenAICompatible("groq", GROQ_BASE_URL, process.env.GROQ_API_KEY, [GROQ_MODEL])
    ])).flat();

    const stale = results.filter(function (r) { return r.configured && r.checkedOk && r.stillListed === false; });
    res.status(200).json({
      ok: true,
      checkedAt: new Date().toISOString(),
      results: results,
      stale: stale,
      summary: stale.length
        ? stale.length + " configured model ID(s) no longer appear in the provider's own model list — likely deprecated/renamed. Check NORI env vars: " + stale.map(function (s) { return s.provider + "=" + s.model; }).join(", ")
        : "All configured, checkable model IDs are still listed by their providers."
    });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
};
