/* NORI HTML-SAFE V1 — single shared source of truth for HTML-escaping.
   ---------------------------------------------------------------------------
   Before this file, ~10 UI files each carried their own private copy of the
   same escapeHtml()/esc() function. That's not a bug on its own — every copy
   escaped correctly — but it meant a future audit or fix had to find and
   verify every copy individually instead of one place. This file changes
   nothing about what gets escaped; it just gives every other file one
   implementation to call. Each of those files keeps its own local esc()/
   escapeHtml() name (so nothing that calls them had to change) and now just
   delegates to NoriHtmlSafe.escapeHtml, falling back to its original inline
   version if this file somehow isn't loaded yet. No feature, route, or
   rendering behavior is changed by this file.
   Load this before every other UI script (see index.html). */
(function (g) {
  "use strict";
  function escapeHtml(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  g.NoriHtmlSafe = { escapeHtml: escapeHtml, version: "1" };
})(window);
