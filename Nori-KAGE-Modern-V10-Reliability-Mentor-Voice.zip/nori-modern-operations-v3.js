/* NORI MODERN OPERATIONS V3
 * Exposes the existing Nori V3 systems through the KAGE Modern interface.
 * No new AI provider, no avatar engine, no replacement auth.
 */
(function(g){
  'use strict';
  const esc=g.NoriHtmlSafe?.escapeHtml||((s)=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])));
  const $=s=>document.querySelector(s);
  const safe=(fn,fb=null)=>{try{return fn()}catch(_){return fb}};
  const asyncSafe=async(fn,fb=null)=>{try{return await fn()}catch(_){return fb}};
  function route(hash){
    try{location.hash=hash;if(typeof g.noriRoute==='function')g.noriRoute(hash);else if(typeof g.noriRoute==='function')g.noriRoute();}catch(_){location.hash=hash}
  }
  function modal(title,html,wide=true){
    const root=$('#modalRoot'); if(!root)return;
    root.innerHTML=`<div class="modal-back"><div class="modal ${wide?'wide':''} nori-ops-modal"><div class="modal-head"><div><span class="eyebrow">NORI / OPERATIONS</span><b>${esc(title)}</b></div><button class="modal-close" id="noriOpsClose">×</button></div><div class="modal-body" id="noriOpsBody">${html}</div></div></div>`;
    $('#noriOpsClose')?.addEventListener('click',()=>root.innerHTML='');
  }
  function card(id,title,desc,action,meta='READY'){
    return `<button class="nori-op-card" data-nori-op="${esc(id)}"><span class="nori-op-meta">${esc(meta)}</span><b>${esc(title)}</b><small>${esc(desc)}</small><i>→</i></button>`;
  }
  const FEATURES=[
    ['chat','Meet Nori','Nori brain, academic context, planning and conversation'],
    ['study','Study & Planning','Goals, study sessions, priorities and execution'],
    ['results','Results & Analytics','Recorded assessments, academic diagnosis and trends'],
    ['recovery','Recovery System','Backlog, recovery signals, Human Override and recovery intelligence'],
    ['calendar','Calendar','Assignments, exams, study sessions and scheduled events'],
    ['alarms','Voice Alarms','Native-ready Nori alarms and wake conversations'],
    ['knowledge','Knowledge Hub','Library files, sources, WPS and YouTube learning routes'],
    ['notes','AI Notes','Generate and store key points, summaries and keywords'],
    ['memory','Memory','Confirmed memories and personal context controls'],
    ['goals','Goals & Preferences','Academic targets and communication/study preferences'],
    ['actions','Action Center','Proposed actions, confirmations, undo and operation audit'],
    ['navigation','Navigation Brain','Open subjects, tools, systems and known app destinations'],
    ['learning','Learning System','Learning profile, source-aware improvement and feedback'],
    ['selfimprove','Self-Improve','Validated improvement proposals and review history'],
    ['integrity','System Integrity','Rules, verification, reconciliation and protected state'],
    ['privacy','Privacy & Security','Permissions, private mode and security controls'],
    ['voice','Voice Center','Voice input, spoken responses and native voice status'],
    ['focus','Focus & Protection','Focus policy, protected apps and study protection'],
    ['visual','Visual Tools','Static visual generation and Nori visual state'],
    ['admin','Administration','Administrator-only review and controls when admitted'],
    ['diagnostics','Diagnostics','Capability, auth, brain, native and storage health'],
    ['backup','Data & Backup','Export/import a portable local Nori state backup']
  ];
  function openCenter(){
    modal('NORI SYSTEMS',`<div class="nori-ops-intro"><b>All connected Nori systems</b><span>This panel is the operational directory. It does not create a second AI or second account system.</span></div><div class="nori-ops-grid">${FEATURES.map(x=>card(...x)).join('')}</div><div class="nori-ops-footer"><span>2.5D AVATAR: intentionally disabled</span><span>NORI V3 CORE: ACTIVE</span></div>`);
    document.querySelectorAll('[data-nori-op]').forEach(b=>b.addEventListener('click',()=>openFeature(b.dataset.noriOp)));
  }
  async function openFeature(id){
    if(id==='chat'){document.querySelector('[data-action="chat"]')?.click();return;}
    if(id==='voice'){document.querySelector('[data-action="voice"]')?.click();return;}
    if(id==='calendar'){route('#/calendar');return;}
    if(id==='alarms'){route('#/alarms');return;}
    if(id==='knowledge'){
      route('#/settings#knowledge');return;
    }
    if(id==='notes'){document.querySelector('[data-action="notes"]')?.click();return;}
    if(id==='recovery'){route('#/recover');return;}
    if(id==='study'){route('#/study');return;}
    if(id==='results'){route('#/results');return;}
    if(id==='memory'){route('#/settings#memory');return;}
    if(id==='goals'){route('#/settings#goals');return;}
    if(id==='actions'){if(g.NoriActionCenterV27?.open){g.NoriActionCenterV27.open();return;}route('#/command');return;}
    if(id==='navigation'){g.NoriNavigation?.open?.();return;}
    if(id==='learning'){route('#/settings#learning');return;}
    if(id==='selfimprove'){if(g.NoriSelfImproveLabV27?.open){g.NoriSelfImproveLabV27.open();return;}route('#/settings#self-improve');return;}
    if(id==='integrity'){route('#/integrity');return;}
    if(id==='privacy'){route('#/settings#privacy');return;}
    if(id==='focus'){route('#/settings#features');return;}
    if(id==='visual'){
      modal('NORI VISUAL TOOLS',`<div class="nori-ops-form"><label>Describe what Nori should visualize<input id="noriVisualPrompt" placeholder="e.g. a clean diagram of the water cycle"></label><button class="btn dark" id="noriVisualGenerate">GENERATE VISUAL</button><div id="noriVisualStatus" class="row-sub"></div></div>`);
      $('#noriVisualGenerate').onclick=async()=>{const p=$('#noriVisualPrompt')?.value.trim();if(!p)return;$('#noriVisualStatus').textContent='Generating…';try{const r=await g.NoriVisualV26?.generate?.(p);$('#noriVisualStatus').textContent=r?'Visual generated.':'Visual provider unavailable.'}catch(e){$('#noriVisualStatus').textContent='Visual generation unavailable: '+e.message}};
      return;
    }
    if(id==='admin'){if(g.NoriAdminConsole?.mount){modal('ADMINISTRATION','<div id="noriAdminHost"></div>');g.NoriAdminConsole.mount();}else route('#/settings#admin-review');return;}
    if(id==='diagnostics'){openDiagnostics();return;}
    if(id==='backup'){openBackup();return;}
  }
  function openDiagnostics(){
    const checks=[
      ['Authentication',!!g.NoriSyncAuth?.configured?.(),'Supabase auth configured'],
      ['Session',!!safe(()=>g.NoriSyncAuth.session()?.data?.session,false),'Session available now'],
      ['Brain loop',!!g.NoriBrainLoopV365,'Nori brain loop loaded'],
      ['Assistance engine',!!g.NoriAssistanceV36,'Academic assistance engine loaded'],
      ['Knowledge hub',!!g.NoriKnowledgeHub,'Library/learning hub loaded'],
      ['Action core',!!g.NoriActionCoreV27,'Confirmed actions + undo loaded'],
      ['Recovery intelligence',!!g.NoriRecoveryIntelligenceV26,'Recovery engine loaded'],
      ['Calendar',!!g.noriCalendar,'Calendar engine loaded'],
      ['Voice alarms',!!g.noriVoiceAlarms,'Alarm engine loaded'],
      ['Time tools',!!g.NoriTimeToolsV35,'Timer/stopwatch engine loaded'],
      ['Native bridge',!!(g.Capacitor?.Plugins),'Capacitor native bridge detected'],
      ['Unified state',!!g.NoriUnifiedState?.snapshot,'Single local Nori state contract loaded'],
      ['Modern bridge',!!g.NoriModernBridge,'Modern-to-Nori bridge loaded']
    ];
    modal('NORI DIAGNOSTICS',`<div class="nori-diag-list">${checks.map(x=>`<div class="nori-diag-row"><span class="${x[1]?'ok':'warn'}">${x[1]?'●':'○'}</span><div><b>${esc(x[0])}</b><small>${esc(x[2])}</small></div><strong>${x[1]?'READY':'NOT LOADED'}</strong></div>`).join('')}</div><div class="nori-ops-footer"><span>VERSION ${esc(g.NORI_MODERN_CONFIG?.appVersion||'NORI')}</span><span>ANDROID API ${esc(g.NORI_MODERN_CONFIG?.targetAndroidApi||'—')}</span></div>`);
  }
  function openBackup(){
    modal('DATA & BACKUP',`<div class="nori-ops-intro"><b>Portable local backup</b><span>Exports the Modern UI state plus selected Nori local records. Secrets and authentication tokens are never exported.</span></div><div class="mini-actions"><button class="btn dark" id="noriExport">EXPORT BACKUP</button><button class="btn" id="noriImport">IMPORT BACKUP</button><input id="noriImportFile" type="file" accept="application/json" hidden></div><div id="noriBackupStatus" class="row-sub" style="margin-top:12px"></div>`);
    $('#noriExport').onclick=()=>{
      const keys=['kage_state_v3','nori_unified_state_v1','nori_calendar_events_v1','nori_calendar_exceptions_v1','nori_v27_reminders','nori_v27_operations','nori_time_tools_v35','nori_v26_memory','nori_assistance_profile_v36','nori_command_assignments','nori_eval_history_all_subjects','nori_recovery_records','nori_academic_mistakes_v14'];
      const data={format:'NORI-LOCAL-BACKUP-V2',schema:1,createdAt:new Date().toISOString(),data:{}};
      keys.forEach(k=>{try{const v=localStorage.getItem(k);if(v!==null)data.data[k]=JSON.parse(v)}catch(_){}});
      const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='nori-backup-'+new Date().toISOString().slice(0,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);$('#noriBackupStatus').textContent='Backup exported.';
    };
    $('#noriImport').onclick=()=>$('#noriImportFile').click();
    $('#noriImportFile').onchange=async e=>{const f=e.target.files?.[0];if(!f)return;try{const d=JSON.parse(await f.text());if(!['NORI-LOCAL-BACKUP-V1','NORI-LOCAL-BACKUP-V2'].includes(d.format))throw Error('Unsupported backup format');Object.entries(d.data||{}).forEach(([k,v])=>localStorage.setItem(k,JSON.stringify(v)));try{g.NoriUnifiedState?.rebuild?.();}catch(_){} $('#noriBackupStatus').textContent='Backup imported. Reload Nori to rehydrate all screens.';}catch(err){$('#noriBackupStatus').textContent='Import failed: '+err.message}};
  }
  function openTimer(){
    modal('NORI TIMER',`<div class="nori-ops-form"><label>Duration (minutes)<input id="noriTimerMin" type="number" min="1" max="1440" value="25"></label><label>Label<input id="noriTimerLabel" value="Study focus"></label><div class="mini-actions"><button class="btn dark" id="noriTimerStart">START TIMER</button><button class="btn" id="noriTimerStop">STOP TIMER</button></div><div id="noriTimerStatus" class="row-sub"></div></div>`);
    $('#noriTimerStart').onclick=()=>{const m=Math.max(1,Math.min(1440,Number($('#noriTimerMin').value)||25));if(g.NoriTimeToolsV35?.setTimer){g.NoriTimeToolsV35.setTimer(m*60,$('#noriTimerLabel').value||'Nori timer');$('#noriTimerStatus').textContent=`Timer running for ${m} minutes.`;}else $('#noriTimerStatus').textContent='Nori time tools are unavailable.'};
    $('#noriTimerStop').onclick=()=>{g.NoriTimeToolsV35?.stopTimer?.();$('#noriTimerStatus').textContent='Timer stopped.'};
  }
  function openSettings(){
    const body=document.createElement('div');
    if(g.noriRenderSettingsV34){try{body.appendChild(g.noriRenderSettingsV34());modal('NORI SETTINGS','<div id="noriFullSettings"></div>',true);$('#noriFullSettings').appendChild(body.firstChild);return}catch(_){}}
    modal('NORI SETTINGS',`<div class="nori-ops-grid">${FEATURES.slice(1,18).map(x=>card(...x)).join('')}</div>`);
    document.querySelectorAll('[data-nori-op]').forEach(b=>b.onclick=()=>openFeature(b.dataset.noriOp));
  }
  function intercept(e){
    const a=e.target.closest?.('[data-action]');
    if(a){
      const id=a.dataset.action;
      if(id==='timer'){e.preventDefault();e.stopImmediatePropagation();openTimer();return;}
      if(id==='library'){e.preventDefault();e.stopImmediatePropagation();openFeature('knowledge');return;}
    }
    const setting=e.target.closest?.('[data-setting]');
    if(setting){e.preventDefault();e.stopImmediatePropagation();openSettings();return;}
  }
  document.addEventListener('click',intercept,true);
  function mountLauncher(){
    if(document.getElementById('noriOpsLauncher')) return;
    const b=document.createElement('button');b.id='noriOpsLauncher';b.type='button';b.title='Nori Systems';b.innerHTML='<span>◈</span><b>NORI</b>';
    b.onclick=()=>openCenter();document.body.appendChild(b);
  }
  document.addEventListener('DOMContentLoaded',mountLauncher);
  window.addEventListener('nori:auth-ready',mountLauncher);
  g.NoriModernOperationsV3={openCenter,openFeature,openDiagnostics,openBackup,openTimer,openSettings,features:FEATURES};
  document.addEventListener('nori:auth-ready',()=>{document.body.dataset.noriOperations='ready'});
})(window);
