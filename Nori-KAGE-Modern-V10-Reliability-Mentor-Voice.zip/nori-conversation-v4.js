/* NORI CONVERSATION V4 — natural conversation orchestration.
   Makes Nori able to open, continue, deepen, clarify, and gracefully end conversations.
   It does not initiate unsolicited background conversations; proactive openings are
   only returned when the user is already in a Nori surface or explicitly enabled it.
*/
(function(g){'use strict';
  const KEY='nori_conversation_v4_meta';
  const COOLDOWN=90*1000;
  function read(){try{return JSON.parse(localStorage.getItem(KEY)||'{}')||{}}catch(e){return {}}}
  function write(x){try{localStorage.setItem(KEY,JSON.stringify(x))}catch(e){}}
  function clean(s){return String(s||'').replace(/\s+/g,' ').trim()}
  function hour(){return new Date().getHours()}
  function timeBand(){const h=hour();return h<5?'late-night':h<12?'morning':h<17?'afternoon':h<22?'evening':'night'}
  function recent(){try{return g.noriConversationV3&&g.noriConversationV3.context?g.noriConversationV3.context():{recentTurns:[],lastIntent:'general',lastAffect:'calm',threadTopic:''}}catch(e){return {recentTurns:[],lastIntent:'general',lastAffect:'calm',threadTopic:''}}}
  function lastUser(ctx){const a=(ctx&&ctx.recentTurns)||[];for(let i=a.length-1;i>=0;i--)if(a[i].role==='user')return a[i];return null}
  function lastAssistant(ctx){const a=(ctx&&ctx.recentTurns)||[];for(let i=a.length-1;i>=0;i--)if(a[i].role==='assistant')return a[i];return null}
  function hasQuestion(ctx){const u=lastUser(ctx);return !!(u&&/[?]$/.test(clean(u.content)))}
  function conversationState(){const ctx=recent(),u=lastUser(ctx),a=lastAssistant(ctx);return {ctx,u,a,topic:ctx.threadTopic||'',intent:ctx.lastIntent||'general',affect:ctx.lastAffect||'calm'};}

  function opening(opts){
    opts=opts||{};const s=conversationState(), band=timeBand();
    if(opts.reason==='alarm') return band==='morning'?'Good morning. Your alarm is up. Let’s get you oriented before we start.':'Nori here. Your alarm is active. What needs your attention first?';
    if(opts.reason==='return'){
      if(s.topic) return 'Welcome back. We were working on '+s.topic+'. Do you want to continue that or switch direction?';
      return band==='morning'?'Good morning. What are we handling first?':'Welcome back. What do you want to work through?';
    }
    if(s.affect==='frustrated'||s.affect==='firm') return 'Alright. Let’s deal with the actual problem. What changed?';
    if(s.intent==='academic') return 'I’m with you. What part are we working on now?';
    if(s.topic) return 'We can continue from '+s.topic+'. What’s the next part?';
    return band==='morning'?'Good morning. What’s first?':band==='evening'?'I’m here. What do you want to handle tonight?':'What’s on your mind?';
  }

  function followUp(reply,opts){
    const s=conversationState(), r=clean(reply), o=opts||{};
    if(!r) return '';
    if(o.forceQuestion) return r.replace(/[.!]?$/,'')+' What do you want to do next?';
    if(hasQuestion(s.ctx)) return r;
    if(s.intent==='planning') return r+' What should we lock in first?';
    if(s.intent==='analysis') return r+' Does that match what you were trying to figure out?';
    if(s.intent==='academic') return r+' Want to continue with the next step?';
    return r;
  }

  function classifyTurn(text){
    const t=clean(text).toLowerCase();
    if(/^(yeah|yes|yep|no|nope|exactly|right|okay|ok|sure|continue|go on)$/.test(t))return 'continuation';
    if(/^(why|how|what|when|where|who|can|could|would|should)\b/.test(t)||/[?]$/.test(t))return 'question';
    if(/\b(but|however|actually|wait|no,|i mean)\b/.test(t))return 'correction';
    if(/\b(let's|we should|i need to|i want to|plan|schedule)\b/.test(t))return 'planning';
    return 'statement';
  }

  function shouldInitiate(opts){
    opts=opts||{};if(!opts.surfaceActive)return false;if(opts.enabled===false)return false;
    const s=read(),now=Date.now();if(now-(s.lastInitiated||0)<COOLDOWN)return false;
    const ctx=recent();if(!ctx||!ctx.recentTurns||!ctx.recentTurns.length)return true;
    const u=lastUser(ctx);const a=lastAssistant(ctx);if(u&&a&&new Date(a.at).getTime()>new Date(u.at).getTime())return false;
    return true;
  }
  function markInitiated(){const s=read();s.lastInitiated=Date.now();write(s)}
  function initiate(opts){if(!shouldInitiate(opts))return null;markInitiated();return opening(opts)}

  function systemPrompt(context){
    const s=conversationState();
    return {
      conversation_contract:[
        'Speak like an intelligent personal assistant, not a scripted help desk.',
        'Remember the current thread and answer the actual point before adding a follow-up.',
        'When the user is casual, be conversational; when academic, become precise and structured.',
        'Do not ask a question after every sentence. Use follow-up questions only when they move the conversation forward.',
        'If the user corrects you, acknowledge the correction and continue from the corrected premise.',
        'If the user gives a short reply such as yes/no/continue, resolve it against the active thread before asking for clarification.',
        'When a conversation naturally ends, allow it to end instead of manufacturing another topic.',
        'Never claim to have performed an action unless the connected Nori system actually completed it.'
      ],
      thread:s.topic,intent:s.intent,affect:s.affect,lastUser:s.u&&s.u.content||'',lastAssistant:s.a&&s.a.content||'',input:clean(context&&context.input||'')
    };
  }

  g.noriConversationV4={
    opening,followUp,classifyTurn,shouldInitiate,initiate,markInitiated,systemPrompt,state:conversationState,
    getConfig:()=>({cooldownMs:COOLDOWN,proactiveBackground:false})
  };
})(window);
