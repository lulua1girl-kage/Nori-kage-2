/* NORI RESILIENCE V1 — failure-aware runtime, offline degradation, self-diagnostics. */
(function(g){'use strict';
 const KEY='nori_resilience_v1';
 const state={online:navigator.onLine!==false,api:'unknown',lastError:null,lastOk:null,failures:0,degraded:false};
 function persist(){try{localStorage.setItem(KEY,JSON.stringify(state))}catch(_){} }
 function set(p){Object.assign(state,p);persist();try{g.dispatchEvent(new CustomEvent('nori:resilience',{detail:Object.assign({},state)}))}catch(_){} }
 addEventListener('online',()=>set({online:true,degraded:false})); addEventListener('offline',()=>set({online:false,degraded:true}));
 async function health(){
  if(!g.NoriApiV1)return set({api:'missing',degraded:true});
  try{const c=await g.NoriApiV1.capabilities();set({api:'healthy',lastOk:new Date().toISOString(),failures:0,degraded:false,capabilities:c});return c}
  catch(e){set({api:'unavailable',lastError:String(e&&e.message||e),failures:state.failures+1,degraded:true});return null}
 }
 function status(){return Object.assign({},state)}
 function localFallback(message){
  const m=String(message||'').trim(); if(!m)return 'I’m here. The online brain is unavailable, but your local Nori systems are still running.';
  return state.online?'I hit a temporary Nori service problem. Your local systems are still available; try that again in a moment.':'I’m offline right now. I can still work with your saved Nori data, timers, navigation, and other local features.';
 }
 g.NoriResilienceV1={state,status,health,set,localFallback,version:1};
})(window);
