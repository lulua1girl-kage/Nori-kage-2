/* NORI VOICE SESSION V1 — coordinates persistent session, mute semantics, continuity and power hints. */
(function(g){'use strict'; const KEY='nori_voice_session_v1';
 const s={active:false,muted:false,startedAt:null,lastTurnAt:null,mode:'foreground',powerMode:'normal'};
 function save(){try{localStorage.setItem(KEY,JSON.stringify(s))}catch(_){};try{g.dispatchEvent(new CustomEvent('nori:voice-session',{detail:Object.assign({},s)}))}catch(_){} }
 function start(mode){s.active=true;s.muted=false;s.startedAt=s.startedAt||new Date().toISOString();s.mode=mode||'foreground';save();return s}
 function mute(v){s.muted=!!v;save();return s}
 function turn(){s.lastTurnAt=new Date().toISOString();save()}
 function stop(){s.active=false;s.muted=false;s.startedAt=null;save();return s}
 function setPower(mode){s.powerMode=['normal','balanced','low'].includes(mode)?mode:'normal';save()}
 function get(){return Object.assign({},s)}
 g.NoriVoiceSessionV1={start,mute,turn,stop,setPower,get,version:1};
})(window);
