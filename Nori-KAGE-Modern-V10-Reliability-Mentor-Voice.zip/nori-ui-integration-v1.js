/* Nori UI Integration V1
 * Exposes the existing KAGE/New Era systems through the simple Nori five-tab UI.
 * No academic engine is replaced; this layer only organizes and links existing systems.
 */
(function(){
  'use strict';
  if(window.NoriUIIntegrationV1) return;

  const routes={
    home:'#/', study:'#/study', tasks:'#/tasks', results:'#/results', analytics:'#/analytics', exams:'#/exams', diagnostic:'#/diagnostic',
    recovery:'#/recover', backlog:'#/phases/phase-5/backlog-mapping-priority/backlog-subject-recovery-map', verification:'#/verification', consequences:'#/consequences',
    progress:'#/progress', phases:'#/phases', calendar:'#/calendar', alarms:'#/alarms', focus:'#/focus', command:'#/command',
    knowledge:'#/settings#knowledge', learning:'#/settings#learning', memory:'#/settings#memory', integrity:'#/integrity', privacy:'#/settings#privacy',
    data:'#/settings#data', profile:'#/profile', settings:'#/settings', meet:'#/meet-nori', timeline:'#/timeline', notifications:'#/notifications'
  };

  function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function card(title,desc,href,tag){return `<a class="nui-card" href="${href}"><span class="nui-card-main"><b>${esc(title)}</b><small>${esc(desc)}</small></span>${tag?`<span class="nui-tag">${esc(tag)}</span>`:'<span class="nui-arrow">→</span>'}</a>`;}
  function section(title,eyebrow,body){return `<section class="nui-section"><div class="nui-section-head"><div><span class="nui-eyebrow">${esc(eyebrow||'NORI')}</span><h3>${esc(title)}</h3></div></div><div class="nui-grid">${body}</div></section>`;}
  function inject(root,html){const wrap=document.createElement('div');wrap.className='nui-integration';wrap.innerHTML=html;root.appendChild(wrap);}

  function home(root){
    inject(root,
      section('Your academic command map','NORI / ACADEMIC SYSTEM',
        card('Study Center','Sessions, subjects, assignments and study execution.',routes.study,'OPEN')+
        card('Results & Analytics','Recorded results, trends and evidence.',routes.results,'OPEN')+
        card('Exam Center','Model exams and assessment planning.',routes.exams,'OPEN')+
        card('Recovery','Backlog, recovery work and verification.',routes.recovery,'OPEN')+
        card('Awards & Merit','Merit, Distinction, Excellence, Honor and Elite records.',routes.progress,'OPEN')+
        card('Phase Forms','The structured KAGE/New Era records behind Nori.',routes.phases,'OPEN')
      )+
      section('Plan & execution','NORI / DAILY CONTROL',
        card('Calendar','School, exams, assignments and scheduled work.',routes.calendar)+
        card('Smart Alarms','Organized reminders and contextual briefings.',routes.alarms)+
        card('Focus Mode','Dedicated study execution and focus tracking.',routes.focus)+
        card('Adaptive Command','Nori-generated actions from current state.',routes.command)
      )+
      `<div class="nui-note"><b>How this works</b><span>Nori remains the simple interface. These systems stay available when you need their detail instead of filling the Home screen with every control.</span></div>`
    );
  }

  function recover(root){
    inject(root,
      section('Recovery command','PHASE 5 / RECOVERY',
        card('Recovery Overview','Current recovery state and subject-level catch-up.',routes.recovery,'ACTIVE')+
        card('Academic Backlog','Map unfinished work by subject and priority.',routes.backlog)+
        card('Recovery Verification','Record evidence that recovery work was actually completed.',routes.verification)+
        card('Emergency Recovery','Open the structured emergency recovery workflow.', '#/phases/phase-5/emergency-recovery', 'PHASE 5')+
        card('Active Controls','Review current recovery-related controls and decisions.',routes.consequences)+
        card('Recovery Map','Connect weak subjects to concrete recovery work.', '#/phases/phase-5/backlog-mapping-priority/backlog-subject-recovery-map')
      )+
      section('Recovery rules & integrity','PROTECTION / HUMAN OVERRIDE',
        card('System Integrity','See why Nori made a system-level decision and review override controls.',routes.integrity)+
        card('Phase Forms','Open the underlying handbook records instead of relying on a summary.',routes.phases)+
        card('System Timeline','Review what Nori recorded and when.',routes.timeline)
      )+
      `<div class="nui-note"><b>Human Override stays visible</b><span>Recovery is a support system, not an automatic judgment. If reality changes, the underlying reassessment and integrity paths remain accessible.</span></div>`
    );
  }

  function study(root){
    inject(root,
      section('Study workspace','ACADEMIC / EXECUTION',
        card('Study Center','Subject work, sessions and study execution.',routes.study,'OPEN')+
        card('Assignments','Deadlines, priorities and completion.',routes.tasks)+
        card('Focus Mode','Run focused study blocks and track time.',routes.focus)+
        card('Library & Knowledge','Access stored study material and the knowledge system.',routes.knowledge)+
        card('Learning System','Outcome-based learning and adaptation.',routes.learning)+
        card('Meet Nori','Ask Nori to plan, explain or navigate the study system.',routes.meet)
      )+
      section('Study support','TOOLS',
        card('Notes','Create and manage study notes through Nori.', '#/settings#learning')+
        card('Math Speed','Timed mathematics practice tools.', '#/math-speed')+
        card('Time Tools','Timer, stopwatch and study timing.', '#/time-tools')+
        card('Calendar','Place study work into the larger school schedule.',routes.calendar)
      )
    );
  }

  function tracker(root){
    inject(root,
      section('Academic tracker','PHASE 3 / EXAM COMMAND',
        card('Results','Enter and review recorded assessments.',routes.results,'CORE')+
        card('Analytics','See progress and score trends.',routes.analytics)+
        card('Exam Center','Model exams and assessment planning.',routes.exams)+
        card('Academic Diagnostic','Subject-level diagnosis and evidence.',routes.diagnostic)+
        card('Progress & Awards','Merit ledger and recognition records.',routes.progress)+
        card('Verification','Evidence and verification workflows.',routes.verification)
      )+
      section('KAGE / New Era records','STRUCTURED SYSTEM',
        card('Phase Forms','All structured handbook records.',routes.phases,'CORE')+
        card('Knowledge Hub','Handbook rules and knowledge retrieval.',routes.knowledge)+
        card('System Timeline','Trace recorded decisions and events.',routes.timeline)+
        card('Nori Inbox','System communications and important notices.', '#/inbox')
      )+
      `<div class="nui-note"><b>Evidence first</b><span>Tracker pages use recorded results and structured records; the interface does not invent academic progress.</span></div>`
    );
  }

  function profile(root){
    inject(root,
      section('Nori systems','PROFILE / PERSONAL CONTROL',
        card('Profile','Identity, academic account and progress snapshot.',routes.profile,'ACCOUNT')+
        card('Calendar','Schedule and academic planning.',routes.calendar)+
        card('Smart Alarms','Alarm organization, pre-alerts and contextual briefings.',routes.alarms)+
        card('Knowledge Hub','Handbook, rules and Nori knowledge.',routes.knowledge)+
        card('Memory Governance','Memory and retention controls.',routes.memory)+
        card('Privacy & Permissions','Privacy and capability controls.',routes.privacy)
      )+
      section('System control','RELIABILITY',
        card('System Integrity','Integrity checks, explanations and Human Override.',routes.integrity)+
        card('Data & Backup','Export and local data controls.',routes.data)+
        card('Settings','Organized application settings.',routes.settings)+
        card('Integration Audit','Check cooperation between Nori systems.', '#/smart-integrity')
      )+
      `<div class="nui-note"><b>Nori on the surface. KAGE underneath.</b><span>The visible app stays simple while the detailed academic, recovery, recognition and integrity systems remain accessible here.</span></div>`
    );
  }

  const originals={};
  function wrap(name,extra){
    if(typeof window[name]!=='function') return;
    originals[name]=window[name];
    window[name]=function(root){const result=originals[name].apply(this,arguments);extra(root);return result;};
  }

  wrap('renderHome',home);
  wrap('renderRecover',recover);
  wrap('renderStudy',study);
  wrap('renderTracker',tracker);
  wrap('renderProfile',profile);

  const nav=document.querySelector('.bottom-nav');
  if(nav){
    const b=nav.querySelector('[data-route="recover"]');
    if(b) b.innerHTML='<span>↻</span>RECOVERY';
  }

  window.NoriUIIntegrationV1={version:'1.0.0',routes,originals,refresh:function(){if(typeof window.render==='function')window.render();}};
})();
