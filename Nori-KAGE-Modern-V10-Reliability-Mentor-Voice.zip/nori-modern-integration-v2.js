/* NORI MODERN INTEGRATION BRIDGE
 * The Modern UI is presentation only. Nori V3 remains the source of truth for
 * authentication, brain routing, native voice, KAGE rules, recovery, memory and
 * deterministic academic state.
 */
(function(){
  'use strict';
  const CFG=window.NORI_MODERN_CONFIG||{};
  const native=()=>window.Capacitor?.Plugins||{};
  async function session(){return window.NoriSyncAuth?.session?.()||{data:{session:null}};}
  async function profile(){try{return await window.NoriSyncAuth?.profile?.()||null}catch(_){return null}}
  async function signOut(){
    try{ await window.NoriSyncAuth?.signOut?.(); }catch(_){ }
    try{ await native().NoriAuth?.signOut?.(); }catch(_){ }
    window.NoriAuthGate?.refresh?.();
    document.dispatchEvent(new CustomEvent('nori:modern-signed-out'));
  }
  async function askNori(message, context){
    const s=(await session()).data?.session;
    if(!s) throw new Error('SIGN_IN_REQUIRED');
    // Prefer an already-loaded Nori brain API if V3 exposes one.
    const candidates=['NoriBrain','NoriBrainLoop','NoriAssistanceEngine'];
    for(const name of candidates){
      const obj=window[name];
      try{
        if(obj?.ask) return await obj.ask(message,context||{});
        if(obj?.respond) return await obj.respond(message,context||{});
        if(typeof obj==='function') return await obj(message,context||{});
      }catch(_){ }
    }
    const endpoint=CFG.brainEndpoint||'';
    const unified=window.NoriUnifiedState?.snapshot?.()||null;
    const mergedContext=Object.assign({},context||{},{canonicalState:unified,source:'nori-modern'});
    if(!endpoint) throw new Error('NORI_BRAIN_ENDPOINT_NOT_CONFIGURED');
    const r=await fetch(endpoint,{method:'POST',headers:{'Authorization':'Bearer '+s.access_token,'Content-Type':'application/json'},body:JSON.stringify({message,context:mergedContext})});
    const j=await r.json().catch(()=>({}));
    if(!r.ok) throw new Error(j.error||'NORI_BRAIN_REQUEST_FAILED');
    return j;
  }
  function state(){
    return {user:window.NoriSyncAuth?.user?.()||null,profile:window.NoriProfile||null,native:!!window.NORI_IS_NATIVE,unified:window.NoriUnifiedState?.snapshot?.()||null};
  }
  window.NoriModernBridge={session,profile,signOut,askNori,state};
  window.addEventListener('nori:auth-ready',()=>document.dispatchEvent(new CustomEvent('nori:modern-auth-ready')));
})();
