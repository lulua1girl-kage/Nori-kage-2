/* NORI CANONICAL CONTEXT V1 — one normalized read model for Nori. */
(function(g){'use strict';
  const KEY='nori_canonical_context_v1';
  function safe(fn,fb){try{return fn()}catch(_){return fb}}
  function ls(k,fb){return safe(function(){const x=JSON.parse(localStorage.getItem(k)||'null');return x==null?fb:x},fb)}
  function profile(){return safe(function(){return g.NoriAssistanceV36&&g.NoriAssistanceV36.profile?g.NoriAssistanceV36.profile():{}},{})}
  function buildLocal(){
    const k=ls('kage_state_v3',{}), u=ls('nori_unified_state_v1',{});
    return {profile:Object.assign({},k.profile||{},profile()),subjects:k.subjects||u.subjects||[],assignments:k.assignments||u.assignments||[],studyBlocks:k.studyBlocks||u.studyBlocks||[],merit:k.merit||u.merit||{},alarms:k.alarms||ls('nori_v27_reminders',[]),calendar:ls('nori_calendar_events_v1',[]),memory:ls('nori_v26_memory',{}),preferences:ls('nori_assistance_profile_v36',{}),recovery:ls('nori_recovery_records',[]),results:ls('nori_eval_history_all_subjects',{}),mistakes:ls('nori_academic_mistakes_v14',[]),goals:ls('kage_goals_v1',ls('nori_goals_v1',[])),commandQueue:ls('nori_command_assignments',[]),integrity:ls('nori_integrated_state_v31',{}),timeTools:ls('nori_time_tools_v35',{}),mentorMemory:(g.NoriMentorMemoryV1&&g.NoriMentorMemoryV1.context?g.NoriMentorMemoryV1.context():{}),updatedAt:new Date().toISOString()};
  }
  async function get(){
    const local=buildLocal(); let remote=null;
    try{if(g.NoriApiV1)remote=await g.NoriApiV1.request({mode:'canonical_state'})}catch(_){ }
    const state=Object.assign({},local,remote&&remote.context&&remote.context.canonicalState&&remote.context.canonicalState.state||{});
    const result={version:1,authority:remote&&remote.context&&remote.context.authority||'LOCAL_EVIDENCE',state:state,profile:state.profile||local.profile||{},preferences:state.preferences||local.preferences||{},merit:state.merit||local.merit||{},hasRemote:!!remote};
    try{localStorage.setItem(KEY,JSON.stringify({at:new Date().toISOString(),result:result}))}catch(_){ }
    return result;
  }
  function cached(){return safe(function(){return JSON.parse(localStorage.getItem(KEY)||'null')?.result||null},null)}
  g.NoriCanonicalContextV1={get:get,cached:cached,buildLocal:buildLocal,version:1};
})(window);
