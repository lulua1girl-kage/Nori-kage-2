/* NORI RISK + AGE CONTEXT V1
 * Age is never guessed from voice, face, writing style, or appearance.
 * Behavior changes only from an explicit profile/platform signal.
 */
(function(g){'use strict';
  const KEY='nori_user_context_v1';
  function load(){try{return JSON.parse(localStorage.getItem(KEY)||'{}')}catch(_){return{}}}
  function save(x){try{localStorage.setItem(KEY,JSON.stringify(x))}catch(_){}}
  function normalizeAgeBand(v){v=String(v||'unknown').toLowerCase();return ['minor','college','adult','unknown'].includes(v)?v:'unknown'}
  function setAgeBand(b,source){const x=load();x.ageBand=normalizeAgeBand(b);x.ageSource=source||'user';x.updatedAt=new Date().toISOString();save(x);return x}
  function age(){return load()}
  function risk(text){
    const t=String(text||'').toLowerCase();
    const immediate=/\b(immediate danger|i am in danger|i'm in danger|someone is attacking|being attacked|fire|gas leak|overdose|poisoning|emergency|unsafe right now)\b/.test(t);
    const threat=/\b(threaten|threatened|threatening|blackmail|stalking|someone is hurting|someone hurt me|forced me)\b/.test(t);
    const self=/\b(suicid|self[- ]?harm|kill myself|want to die|end my life|hurt myself)\b/.test(t);
    return {level:immediate?'critical':self?'critical':threat?'high':'normal',immediate:immediate,selfHarmSignal:self,threatSignal:threat,requiresContext:immediate||self||threat};
  }
  g.NoriRiskAgeV1={setAgeBand:setAgeBand,age:age,risk:risk,version:1};
})(window);
